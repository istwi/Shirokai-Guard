# Shirokai Guard — entrada autorizada em arenas

Versão 0.3.0-alpha.1. Minecraft 1.21.1 / Fabric / Java 21.

1. Pare o servidor e substitua os JARs antigos pelos correspondentes em `mods/`.
   Mantenha Fabric API e as dependências já usadas pelos seus mods. Raids exige
   Cobblemon 1.8.3. Não instale duas versões do mesmo mod.
2. Não instale arquivos de `sources/` ou `patches/` como mods.
3. Inicie e configure apenas as regiões desejadas:

   `/sg flag raid_arena entry-mode authorized-only`

O Raids atualizado usa autorização de entrada de uso único. `/raid sair` permite
retornar; `/back`, `/home` ou outros métodos não concedem nova entrada na arena.
Destinos comuns continuam permitidos. `entry`, `exit` e `teleport` existentes
continuam sendo respeitados; evite `exit deny` em arenas que precisam ser evacuadas.

O Guard pode ser instalado sem Raids ou Essentials. Para a integração de raids,
instale a versão atualizada do Raids; o Essentials atualizado evita histórico e
cooldown em teleportes recusados pelo Guard.

Consulte ARENA_ACCESS.md para precedência, configuração e API, e VALIDATION.md para
resultados e limites reais. Os patches se aplicam aos commits de Raids e Essentials
indicados no guia. O código atualizado do Guard está em sources/.

Esta entrega é local: nenhum push ou release remota foi feito.
