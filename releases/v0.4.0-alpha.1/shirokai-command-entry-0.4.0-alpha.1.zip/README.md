# Shirokai Guard 0.4.0-alpha.1 — entrada por comando

Atualize Guard e Essentials (0.3.2-guard.1). O Raids 0.1.20-guard.1 incluído é o
mesmo da entrega anterior; não precisa ser atualizado novamente.
Pare o servidor e substitua as versões antigas dos mods. Não instale duas versões
nem arquivos de patches/sources como mods. Mantenha Fabric API e as dependências
já utilizadas. Minecraft 1.21.1 / Fabric / Java 21; Raids exige Cobblemon 1.8.3.

Configure a região da loja:

/sg flag loja entry-mode command-only
/sg entry-command loja add warp loja

Somente /warp loja autoriza a entrada nessa região. Outro warp, TPA aceito e /back
não autorizam a entrada. Se já estiver dentro, teleporte para outro ponto da mesma
região continua permitido pelas regras de entrada, respeitando as demais flags.

A arena de raid mantém entry-mode authorized-only e /raid entrar, sem alteração.
Para aliases, correspondência exata, outros mods e limites, leia COMMAND_ENTRY.md.
Testes e relatórios estão em COMMAND_ENTRY_VALIDATION.md e reports/.
